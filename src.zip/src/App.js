import { useEffect, useState } from 'react';
import './App.css';
import { collection, getDocs, addDoc } from "firebase/firestore";
import db from "./firebase/FirebaseConfig"

function App() {
  const [firebaseData, setFirebaseData] = useState([])


  console.log(firebaseData)
  useEffect(() => {
    const getData = async () => {
      const querySnapshot = await getDocs(collection(db, "sales"));
      let box = []
      querySnapshot.forEach((doc) => {
        box.push({ id: doc.id, data: doc.data() })
      });
      setFirebaseData(box)
    }
    getData()
  }, [])

  const AddData = async () => {

    const docRef = await addDoc(collection(db, "sales"), {
      title: "I phone 8",
      color: "White",
      storage: 128,
      price: 300
    });

    console.log("doc: ", docRef);
  }


  return (
    <div className="App">
      <h1>Hello</h1>
      <button onClick={() => AddData()}>Add Data</button>

      <div className="">
        {
          firebaseData.map(item => (
            <div className="">
              <h1>{item.data.title}</h1>
              <div style={{ border: "2px solid black", borderRadius: "50%", width: "50px", height: "50px", background: item.data.color }}></div>

              <h2>${item.data.price}</h2>
            </div>
          ))
        }
      </div>

    </div>
  );
}

export default App;
